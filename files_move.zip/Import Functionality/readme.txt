_test() function in "to be replaced in tow_import.inc" should replace existing function in "tow_import.inc", _tow_import_detect_type($str_value) function should be added to the same file.
PHPExcelExtension should be placed into libraries folder.
